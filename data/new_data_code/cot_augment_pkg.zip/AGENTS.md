# Compatibility Directory

This directory is deprecated. Do not add data-pipeline implementation here.

- Shared collection and augmentation interface: `ldm_tts/data.py`
- Existing collection implementation: `ldm_tts/data_collection.py`
- Repository CLI: `scripts/augment_ldm_data.py`
- Tests: `tests/test_data_augmentation.py` and `tests/test_data_collection.py`
- Documentation: `DATA_COLLECTION.md`

Keep credentials in `LLM_API_KEY`; never store keys in source, samples, logs, or
archives. Any compatibility changes here must delegate to the first-party data
interface rather than duplicate its implementation.
